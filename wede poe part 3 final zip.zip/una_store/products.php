<?php
session_start();
include 'DBConn.php';

$result = mysqli_query($conn, "SELECT * FROM tblclothes");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>

    <style>
        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 20px;
        }

        h1
        {
            color: #333;
            margin-bottom: 30px;
        }

        .product
        {
            background: white;
            width: 350px;
            margin: 15px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        .product h3
        {
            margin-top: 0;
            color: #333;
        }

        .price
        {
            font-size: 18px;
            font-weight: bold;
            margin: 15px 0;
        }

        .btn
        {
            display: inline-block;
            background-color: #17b5c8;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn:hover
        {
            background-color: #0f95a5;
        }

        .cart-btn
        {
            display: inline-block;
            margin-top: 30px;
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .cart-btn:hover
        {
            background-color: #0056b3;
        }
    </style>

</head>
<body>

<h1>Clothing Store</h1>

<?php while($row = mysqli_fetch_assoc($result)) { ?>

<div class="product">

    <h3><?php echo $row['name']; ?></h3>

    <p class="price">
        Price: R<?php echo $row['price']; ?>
    </p>

    <a class="btn" href="addToCart.php?id=<?php echo $row['id']; ?>">
        Add To Cart
    </a>

</div>

<?php } ?>

<a class="cart-btn" href="cart.php">
    View Cart
</a>

</body>
</html>