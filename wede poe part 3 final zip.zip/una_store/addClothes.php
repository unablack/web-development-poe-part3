<?php
include 'DBConn.php';

if(isset($_POST['add']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];

    mysqli_query($conn,
    "INSERT INTO tblclothes(name,price)
    VALUES('$name','$price')");

    header("Location: manageClothes.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Clothing</title>
</head>
<body>

<h1>Add Clothing</h1>

<form method="POST">

Name:
<input type="text" name="name" required>

<br><br>

Price:
<input type="number" step="0.01" name="price" required>

<br><br>

<input type="submit" name="add" value="Add Clothing">

</form>

</body>
</html>