<?php
include 'DBConn.php';

$result = mysqli_query($conn,
"SELECT *
 FROM tblorderline
 ORDER BY orderNum DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Orders</title>
</head>
<body>

<h1>Customer Orders</h1>

<table border="1" cellpadding="10">
<tr>
    <th>Order Number</th>
    <th>Clothing ID</th>
    <th>Quantity</th>
    <th>Date</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
    echo "<tr>";
    echo "<td>".$row['orderNum']."</td>";
    echo "<td>".$row['clothingId']."</td>";
    echo "<td>".$row['quantity']."</td>";
    echo "<td>".$row['orderDate']."</td>";
    echo "</tr>";
}
?>

</table>

</body>
</html>