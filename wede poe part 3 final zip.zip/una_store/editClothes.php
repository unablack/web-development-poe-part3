<?php
include 'DBConn.php';

$id = $_GET['id'];

$result = mysqli_query($conn,
"SELECT * FROM tblclothes WHERE id=$id");

$row = mysqli_fetch_assoc($result);

if(isset($_POST['update']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];

    mysqli_query($conn,
    "UPDATE tblclothes
    SET name='$name',
        price='$price'
    WHERE id=$id");

    header("Location: manageClothes.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Clothing</title>
</head>
<body>

<h1>Edit Clothing</h1>

<form method="POST">

Name:
<input
type="text"
name="name"
value="<?php echo $row['name']; ?>"
required>

<br><br>

Price:
<input
type="number"
step="0.01"
name="price"
value="<?php echo $row['price']; ?>"
required>

<br><br>

<input
type="submit"
name="update"
value="Update Clothing">

</form>

</body>
</html>