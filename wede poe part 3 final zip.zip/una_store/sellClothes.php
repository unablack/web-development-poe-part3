<?php
include 'DBConn.php';

$message = "";

if(isset($_POST['submit']))
{
    $brand = $_POST['brand'];
    $description = $_POST['description'];
    $image = $_POST['image'];

    mysqli_query($conn,
    "INSERT INTO tblsellerrequest
    (brand, description, image)
    VALUES
    ('$brand', '$description', '$image')");

    $message = "Request submitted successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sell Clothing</title>

    <style>

        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        .container
        {
            width: 500px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px lightgray;
        }

        input[type=text],
        textarea
        {
            width: 90%;
            padding: 10px;
            margin-top: 5px;
        }

        input[type=submit]
        {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type=submit]:hover
        {
            background-color: #0056b3;
        }

        .message
        {
            color: green;
            font-weight: bold;
        }

        a
        {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: white;
            background-color: #007bff;
            padding: 10px 15px;
            border-radius: 5px;
        }

    </style>

</head>
<body>

<div class="container">

    <h1>Seller Request</h1>

    <p class="message"><?php echo $message; ?></p>

    <form method="POST">

        <p>Brand</p>
        <input type="text" name="brand" required>

        <p>Description</p>
        <textarea name="description" rows="5" required></textarea>

        <p>Image Name</p>
        <input type="text" name="image">

        <br><br>

        <input type="submit"
               name="submit"
               value="Submit Request">

    </form>

    <br>

    <a href="index.php">Home</a>

</div>

</body>
</html>