<?php
include 'DBConn.php';

$id = $_GET['id'];

mysqli_query($conn,
"DELETE FROM tblclothes WHERE id=$id");

header("Location: adminProducts.php");
exit();
?>