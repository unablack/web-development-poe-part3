<!DOCTYPE html>
<html>
<head>
    <title>UNA Store</title>

    <style>

        body
        {
            background-color: #f4f4f4;
            text-align: center;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container
        {
            width: 80%;
            margin: auto;
            padding-top: 40px;
        }

        h1
        {
            color: #333;
            font-size: 40px;
        }

        h2
        {
            color: #555;
        }

        p
        {
            font-size: 18px;
            color: #666;
        }

        ul
        {
            list-style: none;
            padding: 0;
            margin-bottom: 30px;
        }

        li
        {
            margin: 10px;
            font-size: 18px;
        }

        a
        {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            margin: 8px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        a:hover
        {
            background-color: #0056b3;
        }

    </style>

</head>
<body>

<div class="container">

    <h1>UNA Store</h1>

    <h2>Online Clothing Store</h2>

    <p>
        Our goal is to provide customers with an easy way to buy and sell clothing online.
    </p>

    <ul>
        <li>Buy Quality Clothing</li>
        <li>Sell Pre-Owned Clothing</li>
        <li>Secure Online Shopping</li>
    </ul>

    <a href="products.php">Shop Now</a>

    <a href="login.php">Customer Login</a>

    <a href="sellClothes.php">Sell Clothing</a>

    <a href="history.php">Purchase History</a>

    <a href="adminLogin.php">Admin Login</a>

</div>

</body>
</html>