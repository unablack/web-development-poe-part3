<?php
session_start();
include 'DBConn.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Purchase History</title>

    <style>
        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 20px;
        }

        h1
        {
            color: #333;
            margin-bottom: 30px;
        }

        .order
        {
            background: white;
            width: 500px;
            margin: 15px auto;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        .total
        {
            margin-top: 30px;
            background: #007bff;
            color: white;
            width: 350px;
            margin-left: auto;
            margin-right: auto;
            padding: 15px;
            border-radius: 10px;
        }
    </style>

</head>
<body>

<h1>Purchase History</h1>

<?php

$query = mysqli_query($conn,"
SELECT
tblorderline.*,
tblclothes.name,
tblclothes.price
FROM tblorderline
INNER JOIN tblclothes
ON tblorderline.clothingId = tblclothes.id
ORDER BY orderNum
");

$totalPurchases = 0;

while($row = mysqli_fetch_assoc($query))
{
    $subtotal = $row['price'] * $row['quantity'];

    echo "<div class='order'>";
    echo "<strong>Order #:</strong> ".$row['orderNum'];
    echo "<br><br>";
    echo "<strong>Item:</strong> ".$row['name'];
    echo "<br>";
    echo "<strong>Quantity:</strong> ".$row['quantity'];
    echo "<br>";
    echo "<strong>Total:</strong> R".$subtotal;
    echo "</div>";

    $totalPurchases += $subtotal;
}

echo "<div class='total'>";
echo "<h2>Total Purchases: R".$totalPurchases."</h2>";
echo "</div>";

?>

</body>
</html>