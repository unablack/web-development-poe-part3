<?php
include 'DBConn.php';

if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];

    mysqli_query($conn,
    "INSERT INTO tblclothes(name, price)
    VALUES('$name','$price')");

    header("Location: adminProducts.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Product</title>
</head>
<body>

<h1>Add Product</h1>

<form method="POST">

Name:<br>
<input type="text" name="name" required>

<br><br>

Price:<br>
<input type="number" name="price" required>

<br><br>

<input type="submit"
name="submit"
value="Add Product">

</form>

</body>
</html>