<?php
include 'DBConn.php';

if(isset($_GET['approve']))
{
    $id = $_GET['approve'];

    mysqli_query($conn,
    "INSERT INTO tblclothes(name, price)
     SELECT brand, 0
     FROM tblsellerrequest
     WHERE id=$id");

    mysqli_query($conn,
    "DELETE FROM tblsellerrequest
     WHERE id=$id");
}

$result = mysqli_query($conn,
"SELECT * FROM tblsellerrequest");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Seller Requests</title>
</head>
<body>

<h1>Seller Requests</h1>

<?php

while($row = mysqli_fetch_assoc($result))
{
    echo "<b>Brand:</b> ".$row['brand']."<br>";
    echo "<b>Description:</b> ".$row['description']."<br>";
    echo "<b>Image:</b> ".$row['image']."<br>";

    echo "<a href='sellerRequests.php?approve=".$row['id']."'>
    Approve
    </a>";

    echo "<hr>";
}

?>

</body>
</html>