<?php
session_start();
include 'DBConn.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>

    <style>
        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 20px;
        }

        h1
        {
            color: #333;
            margin-bottom: 30px;
        }

        .cart-item
        {
            background: white;
            width: 600px;
            margin: 15px auto;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        .btn
        {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            margin: 5px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn:hover
        {
            background-color: #0056b3;
        }

        .action-link
        {
            text-decoration: none;
            font-weight: bold;
            margin-left: 5px;
        }

        .total
        {
            background: #28a745;
            color: white;
            width: 300px;
            margin: 20px auto;
            padding: 15px;
            border-radius: 10px;
        }
    </style>

</head>
<body>

<h1>Shopping Cart</h1>

<?php

$total = 0;

if(isset($_SESSION['cart']) && count($_SESSION['cart']) > 0)
{
    foreach($_SESSION['cart'] as $id => $qty)
    {
        $query = mysqli_query($conn, "SELECT * FROM tblclothes WHERE id=$id");

        $row = mysqli_fetch_assoc($query);

        if(!$row)
        {
            continue;
        }

        $subtotal = $row['price'] * $qty;

        echo "<div class='cart-item'>";
        echo "<strong>".$row['name']."</strong>";
        echo "<br><br>";
        echo "Quantity: ".$qty;
        echo "<br>";
        echo "Subtotal: R".$subtotal;
        echo "<br><br>";

        echo "<a class='action-link' href='increaseQty.php?id=".$id."'>[+]</a>";
        echo "<a class='action-link' href='decreaseQty.php?id=".$id."'>[-]</a>";
        echo "<a class='action-link' href='removeItem.php?id=".$id."'>[Remove]</a>";

        echo "</div>";

        $total += $subtotal;
    }

    echo "<div class='total'>";
    echo "<h3>Total: R".$total."</h3>";
    echo "</div>";
}
else
{
    echo "<p>Your cart is empty.</p>";
}

?>

<br>

<a class="btn" href="products.php">Continue Shopping</a>

<a class="btn" href="emptyCart.php">Empty Cart</a>

<a class="btn" href="checkout.php">Checkout</a>

</body>
</html>