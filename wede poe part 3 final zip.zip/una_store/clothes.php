<!DOCTYPE html>
<html>
<head>
    <title>Clothing Store</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'DBConn.php';

echo "<h2>Available Clothes</h2>";

$result = $conn->query("SELECT * FROM tblClothes");

if ($result && $result->num_rows > 0) {

    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price (R)</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>".$row['id']."</td>
                <td>".$row['name']."</td>
                <td>".$row['price']."</td>
              </tr>";
    }

    echo "</table>";

} else {
    echo "<p>No clothes available.</p>";
}
?>

</body>
</html>