<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'DBConn.php';

$message = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $sql = "SELECT * FROM tblUser
            WHERE email='$email'
            AND password='$password'
            AND isVerified=1";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        $message = "Invalid login or not verified";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>

    <style>
        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
        }

        nav
        {
            background: #222;
            padding: 15px;
        }

        nav a
        {
            color: white;
            text-decoration: none;
            margin: 10px;
            font-weight: bold;
        }

        .container
        {
            width: 400px;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }

        input
        {
            width: 90%;
            padding: 10px;
            margin-top: 5px;
        }

        button
        {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover
        {
            background: #0056b3;
        }

        table
        {
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
        }

        th, td
        {
            border: 1px solid #ccc;
            padding: 10px 20px;
        }

        th
        {
            background: #007bff;
            color: white;
        }

        .success
        {
            color: green;
            font-weight: bold;
        }

        .error
        {
            color: red;
            font-weight: bold;
        }
    </style>

</head>
<body>

<nav>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
    <a href="adminLogin.php">Admin</a>
    <a href="adminDashboard.php">Dashboard</a>
    <a href="createTable.php">Load Users</a>
</nav>

<div class="container">

<h2>User Login</h2>

<form method="POST">

    <p>Email</p>
    <input
        type="email"
        name="email"
        required
        value="<?php echo $email; ?>">

    <p>Password</p>
    <input
        type="password"
        name="password"
        required>

    <br><br>

    <button type="submit">
        Login
    </button>

</form>

<?php
if(isset($user))
{
    echo "<p class='success'>User ".$user['name']." is logged in</p>";

    echo "
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <tr>
            <td>".$user['id']."</td>
            <td>".$user['name']."</td>
            <td>".$user['email']."</td>
        </tr>
    </table>";
}
?>

<p class="error"><?php echo $message; ?></p>

</div>

</body>
</html>