<?php
session_start();
include 'DBConn.php';

$orderNum = rand(10000,99999);
$sessionId = session_id();

if(isset($_SESSION['cart']))
{
    foreach($_SESSION['cart'] as $id => $qty)
    {
        mysqli_query($conn,
        "INSERT INTO tblorderline
        (orderNum, clothingId, quantity)
        VALUES
        ('$orderNum','$id','$qty')");
    }
}

$_SESSION['cart'] = [];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
</head>
<body>

<h1>Order Successful</h1>

<p>Thank you for your purchase.</p>

<p>
Order Number:
<?php echo $orderNum; ?>
</p>

<p>
Session ID:
<?php echo $sessionId; ?>
</p>

<p>Your shopping cart has been cleared.</p>

<a href="login.php">
Return to Login
</a>

</body>
</html>