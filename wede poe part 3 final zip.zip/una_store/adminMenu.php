<!DOCTYPE html>
<html>
<head>
    <title>Admin Menu</title>

    <style>

        body
        {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        .container
        {
            width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px lightgray;
        }

        h1
        {
            color: #333;
        }

        a
        {
            display: block;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            padding: 12px;
            margin: 10px 0;
            border-radius: 5px;
            font-weight: bold;
        }

        a:hover
        {
            background-color: #0056b3;
        }

    </style>

</head>
<body>

<div class="container">

    <h1>Admin Panel</h1>

    <a href="viewOrders.php">View Orders</a>

    <a href="sellerRequests.php">Seller Requests</a>

    <a href="products.php">View Products</a>

    <a href="index.php">Home</a>

</div>

</body>
</html>