<?php
include 'DBConn.php';

$result = mysqli_query($conn, "SELECT * FROM tblclothes");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Products</title>
</head>
<body>

<h1>Manage Products</h1>

<a href="addProduct.php">Add New Product</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Actions</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>

<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td>R<?php echo $row['price']; ?></td>

    <td>
        <a href="editProduct.php?id=<?php echo $row['id']; ?>">
            Edit
        </a>

        |

        <a href="deleteProduct.php?id=<?php echo $row['id']; ?>">
            Delete
        </a>
    </td>
</tr>

<?php } ?>

</table>

</body>
</html>