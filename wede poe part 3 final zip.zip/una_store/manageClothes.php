<?php
include 'DBConn.php';

if(isset($_GET['delete']))
{
    $id = (int)$_GET['delete'];

    mysqli_query($conn,
    "DELETE FROM tblclothes WHERE id=$id");
}

$result = mysqli_query($conn,
"SELECT * FROM tblclothes");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Clothes</title>
</head>
<body>

<h1>Manage Clothes</h1>

<a href="addClothes.php">Add New Clothing Item</a>

<br><br>

<table border="1" cellpadding="10">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Price</th>
    <th>Actions</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>
<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['name']; ?></td>

<td>R<?php echo $row['price']; ?></td>

<td>
<a href="editClothes.php?id=<?php echo $row['id']; ?>">
Edit
</a>

|

<a href="manageClothes.php?delete=<?php echo $row['id']; ?>">
Delete
</a>

</td>

</tr>

<?php
}
?>

</table>

</body>
</html>