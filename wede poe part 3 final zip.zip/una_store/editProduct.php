<?php
include 'DBConn.php';

$id = $_GET['id'];

if(isset($_POST['update']))
{
    $name = $_POST['name'];
    $price = $_POST['price'];

    mysqli_query($conn,
    "UPDATE tblclothes
    SET name='$name',
        price='$price'
    WHERE id=$id");

    header("Location: adminProducts.php");
    exit();
}

$result = mysqli_query($conn,
"SELECT * FROM tblclothes WHERE id=$id");

$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Product</title>
</head>
<body>

<h1>Edit Product</h1>

<form method="POST">

Name:<br>
<input type="text"
name="name"
value="<?php echo $row['name']; ?>">

<br><br>

Price:<br>
<input type="number"
name="price"
value="<?php echo $row['price']; ?>">

<br><br>

<input type="submit"
name="update"
value="Update Product">

</form>

</body>
</html>